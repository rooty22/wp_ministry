<?php
get_header();
?>

<h3>It's Tarshhhh</h3>

<?php
get_footer();
